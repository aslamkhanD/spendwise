#!/usr/bin/env python3
"""Main launcher for SpendWise CLI application."""

import sys
from spendwise.cli import main

if __name__ == "__main__":
    sys.exit(main())
