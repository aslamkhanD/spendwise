from setuptools import setup, find_packages

setup(
    name="spendwise",
    version="1.0.0",
    description="A modern, modular personal expense and budget tracker CLI built with Python.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "spendwise=spendwise.cli:main",
        ],
    },
)
