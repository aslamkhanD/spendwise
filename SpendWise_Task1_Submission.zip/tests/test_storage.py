"""Tests for SpendWise SQLite storage layer."""

import tempfile
from pathlib import Path
import unittest

from spendwise.exceptions import ExpenseNotFoundError
from spendwise.models import Budget, Expense
from spendwise.storage import Storage


class TestStorage(unittest.TestCase):
    """Test suite for SQLite storage operations."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_spendwise.db"
        self.storage = Storage(db_path=self.db_path)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_add_and_get_expense(self) -> None:
        exp = Expense(
            id=None,
            amount=45.50,
            category="Food",
            description="Lunch with clients",
            date="2026-11-10",
        )
        saved = self.storage.add_expense(exp)
        self.assertIsNotNone(saved.id)
        self.assertEqual(saved.amount, 45.50)

        retrieved = self.storage.get_expense(saved.id)  # type: ignore[arg-type]
        self.assertEqual(retrieved.id, saved.id)
        self.assertEqual(retrieved.category, "Food")
        self.assertEqual(retrieved.description, "Lunch with clients")
        self.assertEqual(retrieved.date, "2026-11-10")

    def test_get_nonexistent_expense(self) -> None:
        with self.assertRaises(ExpenseNotFoundError):
            self.storage.get_expense(9999)

    def test_list_and_filter_expenses(self) -> None:
        self.storage.add_expense(Expense(None, 10.0, "Food", "Snack", "2026-11-01"))
        self.storage.add_expense(Expense(None, 50.0, "Transport", "Train", "2026-11-02"))
        self.storage.add_expense(Expense(None, 25.0, "Food", "Dinner", "2026-11-05"))
        self.storage.add_expense(Expense(None, 100.0, "Housing", "Rent", "2026-10-15"))

        # All expenses
        all_exp = self.storage.list_expenses()
        self.assertEqual(len(all_exp), 4)

        # Filter by category
        food_exp = self.storage.list_expenses(category="Food")
        self.assertEqual(len(food_exp), 2)

        # Filter by month
        nov_exp = self.storage.list_expenses(month="2026-11")
        self.assertEqual(len(nov_exp), 3)

        # Date range
        range_exp = self.storage.list_expenses(start_date="2026-11-02", end_date="2026-11-05")
        self.assertEqual(len(range_exp), 2)

    def test_update_expense(self) -> None:
        saved = self.storage.add_expense(Expense(None, 30.0, "Food", "Groceries", "2026-11-01"))
        updated = self.storage.update_expense(
            expense_id=saved.id,  # type: ignore[arg-type]
            amount=35.0,
            description="Organic Groceries",
        )
        self.assertEqual(updated.amount, 35.0)
        self.assertEqual(updated.description, "Organic Groceries")
        self.assertEqual(updated.category, "Food")  # unchanged

    def test_delete_expense(self) -> None:
        saved = self.storage.add_expense(Expense(None, 20.0, "Books", "Python book", "2026-11-01"))
        deleted = self.storage.delete_expense(saved.id)  # type: ignore[arg-type]
        self.assertEqual(deleted.id, saved.id)

        with self.assertRaises(ExpenseNotFoundError):
            self.storage.get_expense(saved.id)  # type: ignore[arg-type]

    def test_budget_operations(self) -> None:
        b = Budget(category="Food", monthly_limit=500.0, month="2026-11")
        self.storage.set_budget(b)

        fetched = self.storage.get_budget("Food", "2026-11")
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.monthly_limit, 500.0)  # type: ignore[union-attr]

        # Upsert
        b_updated = Budget(category="Food", monthly_limit=600.0, month="2026-11")
        self.storage.set_budget(b_updated)
        fetched2 = self.storage.get_budget("Food", "2026-11")
        self.assertEqual(fetched2.monthly_limit, 600.0)  # type: ignore[union-attr]

        # Delete
        self.assertTrue(self.storage.delete_budget("Food", "2026-11"))
        self.assertIsNone(self.storage.get_budget("Food", "2026-11"))

    def test_totals_and_aggregations(self) -> None:
        self.storage.add_expense(Expense(None, 10.0, "Food", "", "2026-11-01"))
        self.storage.add_expense(Expense(None, 20.0, "Food", "", "2026-11-02"))
        self.storage.add_expense(Expense(None, 30.0, "Transport", "", "2026-11-03"))

        totals = self.storage.get_category_totals(month="2026-11")
        self.assertEqual(len(totals), 2)
        # Should be ordered descending: Food ($30), Transport ($30)
        self.assertEqual(sum(t[1] for t in totals), 60.0)


if __name__ == "__main__":
    unittest.main()
