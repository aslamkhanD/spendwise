"""Integration tests for SpendWise CLI commands."""

import io
import os
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
import unittest

from spendwise.cli import main


class TestCLIIntegration(unittest.TestCase):
    """End-to-end integration tests through the main CLI function."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.temp_dir.name) / "cli_test.db")
        self.old_env = os.environ.get("SPENDWISE_DB")
        os.environ["SPENDWISE_DB"] = self.db_path

    def tearDown(self) -> None:
        if self.old_env is None:
            os.environ.pop("SPENDWISE_DB", None)
        else:
            os.environ["SPENDWISE_DB"] = self.old_env
        self.temp_dir.cleanup()

    def run_cli(self, args: list[str]) -> tuple[int, str]:
        """Run CLI command and capture exit code and standard output."""
        f = io.StringIO()
        with redirect_stdout(f):
            exit_code = main(args)
        return exit_code, f.getvalue()

    def test_cli_add_and_list(self) -> None:
        # Add expense
        code, out = self.run_cli(["add", "-a", "25.50", "-c", "Food", "-d", "Lunch", "--date", "2026-11-01"])
        self.assertEqual(code, 0)
        self.assertIn("Successfully added expense #1", out)

        # List expenses
        code, out = self.run_cli(["list"])
        self.assertEqual(code, 0)
        self.assertIn("Food", out)
        self.assertIn("$25.50", out)

    def test_cli_summary(self) -> None:
        self.run_cli(["add", "-a", "50.00", "-c", "Tech", "--date", "2026-11-02"])
        code, out = self.run_cli(["summary"])
        self.assertEqual(code, 0)
        self.assertIn("Financial Summary", out)
        self.assertIn("$50.00", out)

    def test_cli_budget_flow(self) -> None:
        # Set budget
        code, out = self.run_cli(["budget", "set", "Food", "200", "-m", "2026-11"])
        self.assertEqual(code, 0)
        self.assertIn("Budget for 'Food' set to $200.00", out)

        # Check status
        code, out = self.run_cli(["budget", "status", "-m", "2026-11"])
        self.assertEqual(code, 0)
        self.assertIn("Food", out)
        self.assertIn("$200.00", out)

    def test_cli_invalid_input_error_code(self) -> None:
        # Negative amount
        code, _ = self.run_cli(["add", "-a", "-10", "-c", "Food"])
        self.assertEqual(code, 1)


if __name__ == "__main__":
    unittest.main()
