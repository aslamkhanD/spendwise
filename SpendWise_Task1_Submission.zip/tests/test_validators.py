"""Tests for SpendWise input validation routines."""

from datetime import date, timedelta
import unittest

from spendwise.exceptions import ValidationError
from spendwise.validators import (
    validate_amount,
    validate_category,
    validate_date,
    validate_description,
    validate_id,
    validate_month,
)


class TestValidators(unittest.TestCase):
    """Test suite for validators."""

    def test_validate_amount_valid(self) -> None:
        self.assertEqual(validate_amount(10), 10.0)
        self.assertEqual(validate_amount(19.99), 19.99)
        self.assertEqual(validate_amount("42.505"), 42.51)
        self.assertEqual(validate_amount("100"), 100.0)

    def test_validate_amount_invalid(self) -> None:
        with self.assertRaises(ValidationError):
            validate_amount(0)

        with self.assertRaises(ValidationError):
            validate_amount(-5.0)

        with self.assertRaises(ValidationError):
            validate_amount("not_a_number")

        with self.assertRaises(ValidationError):
            validate_amount(2_000_000_000)

    def test_validate_date(self) -> None:
        today_str = date.today().strftime("%Y-%m-%d")
        yesterday_str = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")

        self.assertEqual(validate_date(None), today_str)
        self.assertEqual(validate_date("today"), today_str)
        self.assertEqual(validate_date("yesterday"), yesterday_str)
        self.assertEqual(validate_date("2026-05-15"), "2026-05-15")

        with self.assertRaises(ValidationError):
            validate_date("invalid-date")

        with self.assertRaises(ValidationError):
            validate_date("2026-02-31")

        with self.assertRaises(ValidationError):
            validate_date("2050-01-01")

        with self.assertRaises(ValidationError):
            validate_date("1960-01-01")

    def test_validate_month(self) -> None:
        curr_month = date.today().strftime("%Y-%m")
        self.assertEqual(validate_month(None), curr_month)
        self.assertEqual(validate_month("this"), curr_month)
        self.assertEqual(validate_month("2026-08"), "2026-08")

        with self.assertRaises(ValidationError):
            validate_month("2026-15")

        with self.assertRaises(ValidationError):
            validate_month("2026/08")

    def test_validate_category(self) -> None:
        self.assertEqual(validate_category("food"), "Food")
        self.assertEqual(validate_category("  grocery shopping "), "Grocery Shopping")

        with self.assertRaises(ValidationError):
            validate_category("")

        with self.assertRaises(ValidationError):
            validate_category("a")

        with self.assertRaises(ValidationError):
            validate_category("evil<script>")

    def test_validate_description(self) -> None:
        self.assertEqual(validate_description(None), "")
        self.assertEqual(validate_description("  Coffee with team  "), "Coffee with team")
        with self.assertRaises(ValidationError):
            validate_description("x" * 256)

    def test_validate_id(self) -> None:
        self.assertEqual(validate_id(1), 1)
        self.assertEqual(validate_id("42"), 42)

        with self.assertRaises(ValidationError):
            validate_id(0)

        with self.assertRaises(ValidationError):
            validate_id(-3)

        with self.assertRaises(ValidationError):
            validate_id("abc")


if __name__ == "__main__":
    unittest.main()
