"""Unit tests for SpendWise data models."""

import unittest

from spendwise.models import Budget, BudgetComparison, Expense


class TestModels(unittest.TestCase):
    """Test suite for models."""

    def test_expense_dict_conversion(self) -> None:
        exp = Expense(
            id=1,
            amount=49.99,
            category="Utilities",
            description="Internet bill",
            date="2026-11-05",
        )
        d = exp.to_dict()
        self.assertEqual(d["id"], 1)
        self.assertEqual(d["amount"], 49.99)
        self.assertEqual(d["category"], "Utilities")

        reconstructed = Expense.from_dict(d)
        self.assertEqual(reconstructed.id, 1)
        self.assertEqual(reconstructed.amount, 49.99)
        self.assertEqual(reconstructed.description, "Internet bill")

    def test_budget_dict_conversion(self) -> None:
        b = Budget(category="Shopping", monthly_limit=300.0, month="2026-11")
        d = b.to_dict()
        self.assertEqual(d["category"], "Shopping")
        self.assertEqual(d["monthly_limit"], 300.0)

        reconstructed = Budget.from_dict(d)
        self.assertEqual(reconstructed.category, "Shopping")
        self.assertEqual(reconstructed.monthly_limit, 300.0)

    def test_budget_comparison(self) -> None:
        comp = BudgetComparison(
            category="Dining",
            monthly_limit=200.0,
            spent=250.0,
            remaining=-50.0,
            percentage_used=125.0,
            is_exceeded=True,
        )
        self.assertTrue(comp.is_exceeded)
        self.assertEqual(comp.remaining, -50.0)


if __name__ == "__main__":
    unittest.main()
