"""Tests for SpendWise ExpenseTracker service layer."""

import json
import tempfile
from pathlib import Path
import unittest

from spendwise.exceptions import ExportImportError, ValidationError
from spendwise.storage import Storage
from spendwise.tracker import ExpenseTracker


class TestExpenseTracker(unittest.TestCase):
    """Test suite for the business logic orchestrator."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_tracker.db"
        self.storage = Storage(db_path=self.db_path)
        self.tracker = ExpenseTracker(storage=self.storage)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_add_expense_with_budget_notice_and_warning(self) -> None:
        # Set a $100 budget for food
        self.tracker.set_budget("Food", 100.0, month="2026-11")

        # 1. Add $50 expense - under 90% threshold, no warning
        exp1, warning1 = self.tracker.add(50.0, "Food", "Groceries", "2026-11-01")
        self.assertIsNone(warning1)
        self.assertEqual(exp1.amount, 50.0)

        # 2. Add $42 expense - total is now $92 (92% of budget), notice triggered
        exp2, warning2 = self.tracker.add(42.0, "Food", "Snacks", "2026-11-02")
        self.assertIsNotNone(warning2)
        self.assertIn("Notice: You have used 92.0%", warning2)  # type: ignore[arg-type]

        # 3. Add $20 expense - total is now $112 (over budget), warning triggered
        exp3, warning3 = self.tracker.add(20.0, "Food", "Dinner", "2026-11-03")
        self.assertIsNotNone(warning3)
        self.assertIn("exceeding your monthly budget", warning3)  # type: ignore[arg-type]

    def test_budget_status_calculation(self) -> None:
        self.tracker.set_budget("Entertainment", 150.0, month="2026-11")
        self.tracker.add(100.0, "Entertainment", "Concert", "2026-11-05")

        status = self.tracker.get_budget_status(month="2026-11")
        self.assertEqual(len(status), 1)
        comp = status[0]
        self.assertEqual(comp.category, "Entertainment")
        self.assertEqual(comp.spent, 100.0)
        self.assertEqual(comp.remaining, 50.0)
        self.assertAlmostEqual(comp.percentage_used, 66.666, places=2)
        self.assertFalse(comp.is_exceeded)

    def test_export_and_import_json(self) -> None:
        self.tracker.add(15.0, "Coffee", "Latte", "2026-11-01")
        self.tracker.add(45.0, "Travel", "Taxi", "2026-11-02")

        export_file = Path(self.temp_dir.name) / "export.json"
        exported_count = self.tracker.export_data(export_file, export_format="json")
        self.assertEqual(exported_count, 2)
        self.assertTrue(export_file.is_file())

        with open(export_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            self.assertEqual(len(data), 2)
            self.assertEqual(data[0]["category"], "Coffee")

        # Import into fresh tracker
        fresh_db = Path(self.temp_dir.name) / "fresh.db"
        fresh_tracker = ExpenseTracker(storage=Storage(db_path=fresh_db))
        imported_count = fresh_tracker.import_data(export_file)
        self.assertEqual(imported_count, 2)
        self.assertEqual(len(fresh_tracker.list()), 2)

    def test_export_and_import_csv(self) -> None:
        self.tracker.add(30.0, "Books", "Python Programming Guide", "2026-11-03")
        export_file = Path(self.temp_dir.name) / "export.csv"
        exported_count = self.tracker.export_data(export_file, export_format="csv")
        self.assertEqual(exported_count, 1)

        fresh_db = Path(self.temp_dir.name) / "fresh_csv.db"
        fresh_tracker = ExpenseTracker(storage=Storage(db_path=fresh_db))
        imported_count = fresh_tracker.import_data(export_file)
        self.assertEqual(imported_count, 1)
        items = fresh_tracker.list()
        self.assertEqual(items[0].category, "Books")
        self.assertEqual(items[0].amount, 30.0)

    def test_invalid_date_range_raises_validation_error(self) -> None:
        with self.assertRaises(ValidationError):
            self.tracker.list(start_date="2026-11-10", end_date="2026-11-05")


if __name__ == "__main__":
    unittest.main()
