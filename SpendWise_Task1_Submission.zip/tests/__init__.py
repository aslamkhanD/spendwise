"""Unit test package for SpendWise CLI."""
