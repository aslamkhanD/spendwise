"""Storage abstraction layer using SQLite for SpendWise.

Ensures ACID compliance, thread safety, and transparent schema setup.
"""

from __future__ import annotations

import os
from pathlib import Path
import sqlite3
from contextlib import contextmanager
from typing import Any, Generator, List, Optional, Sequence, Tuple

from spendwise.exceptions import ExpenseNotFoundError, StorageError
from spendwise.models import Budget, Expense

def _get_default_db_path() -> Path:
    """Determine a safe default path for the database file."""
    if os.environ.get("SPENDWISE_DB"):
        return Path(os.environ["SPENDWISE_DB"])

    # Try user home directory first
    try:
        home_target = Path.home() / ".spendwise" / "spendwise.db"
        home_target.parent.mkdir(parents=True, exist_ok=True)
        return home_target
    except OSError:
        pass

    # Fall back to local data directory next to package
    local_target = Path(__file__).resolve().parent.parent / "data" / "spendwise.db"
    return local_target


class Storage:
    """Manages SQLite database storage for expenses and budgets."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        if db_path is None:
            self.db_path = _get_default_db_path()
        else:
            self.db_path = Path(db_path)

        self._ensure_directory()
        self._init_schema()

    def _ensure_directory(self) -> None:
        """Create parent directory for database file if missing."""
        try:
            if not self.db_path.parent.exists():
                self.db_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as err:
            raise StorageError(
                f"Failed to create storage directory '{self.db_path.parent}': {err}"
            ) from err

    def _get_connection(self) -> sqlite3.Connection:
        """Create and return a configured SQLite connection."""
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=10.0)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON;")
            return conn
        except sqlite3.Error as err:
            raise StorageError(f"Database connection error: {err}") from err

    @contextmanager
    def _connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Context manager that commits/rollbacks and guarantees connection closure."""
        conn = self._get_connection()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_schema(self) -> None:
        """Initialize database tables and indexes if they do not exist."""
        try:
            with self._connection() as conn:
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS expenses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        amount REAL NOT NULL CHECK (amount > 0),
                        category TEXT NOT NULL,
                        description TEXT NOT NULL DEFAULT '',
                        date TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    );
                    """
                )
                conn.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_expenses_date
                    ON expenses (date);
                    """
                )
                conn.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_expenses_category
                    ON expenses (category);
                    """
                )
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS budgets (
                        category TEXT NOT NULL,
                        month TEXT NOT NULL,
                        monthly_limit REAL NOT NULL CHECK (monthly_limit > 0),
                        PRIMARY KEY (category, month)
                    );
                    """
                )
        except sqlite3.Error as err:
            raise StorageError(f"Schema initialization failed: {err}") from err

    def add_expense(self, expense: Expense) -> Expense:
        """Persist a new expense and populate its generated ID.

        Args:
            expense: Expense object to persist.

        Returns:
            Expense: Saved expense with assigned ID.
        """
        sql = """
            INSERT INTO expenses (amount, category, description, date, created_at)
            VALUES (?, ?, ?, ?, ?);
        """
        try:
            with self._connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    sql,
                    (
                        expense.amount,
                        expense.category,
                        expense.description,
                        expense.date,
                        expense.created_at,
                    ),
                )
                generated_id = cursor.lastrowid
                expense.id = generated_id
                return expense
        except sqlite3.Error as err:
            raise StorageError(f"Failed to save expense: {err}") from err

    def get_expense(self, expense_id: int) -> Expense:
        """Retrieve an expense by ID.

        Args:
            expense_id: ID of the expense to find.

        Returns:
            Expense: The retrieved expense.

        Raises:
            ExpenseNotFoundError: If no expense exists with the given ID.
        """
        sql = "SELECT id, amount, category, description, date, created_at FROM expenses WHERE id = ?;"
        try:
            with self._connection() as conn:
                row = conn.execute(sql, (expense_id,)).fetchone()
                if row is None:
                    raise ExpenseNotFoundError(expense_id)
                return Expense(
                    id=row["id"],
                    amount=row["amount"],
                    category=row["category"],
                    description=row["description"],
                    date=row["date"],
                    created_at=row["created_at"],
                )
        except sqlite3.Error as err:
            raise StorageError(f"Database error while querying expense #{expense_id}: {err}") from err

    def list_expenses(
        self,
        category: Optional[str] = None,
        month: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sort_by: str = "date",
        order: str = "ASC",
    ) -> List[Expense]:
        """Query expenses with filtering and ordering."""
        allowed_sort = {"date": "date", "amount": "amount", "category": "category", "id": "id"}
        col = allowed_sort.get(sort_by.lower(), "date")
        ord_dir = "DESC" if order.upper() == "DESC" else "ASC"

        clauses: List[str] = []
        params: List[Any] = []

        if category:
            clauses.append("category = ?")
            params.append(category)

        if month:
            clauses.append("strftime('%Y-%m', date) = ?")
            params.append(month)

        if start_date:
            clauses.append("date >= ?")
            params.append(start_date)

        if end_date:
            clauses.append("date <= ?")
            params.append(end_date)

        where_sql = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = f"""
            SELECT id, amount, category, description, date, created_at
            FROM expenses
            {where_sql}
            ORDER BY {col} {ord_dir}, id {ord_dir};
        """

        try:
            with self._connection() as conn:
                rows = conn.execute(sql, params).fetchall()
                return [
                    Expense(
                        id=r["id"],
                        amount=r["amount"],
                        category=r["category"],
                        description=r["description"],
                        date=r["date"],
                        created_at=r["created_at"],
                    )
                    for r in rows
                ]
        except sqlite3.Error as err:
            raise StorageError(f"Failed to query expenses: {err}") from err

    def update_expense(
        self,
        expense_id: int,
        amount: Optional[float] = None,
        category: Optional[str] = None,
        description: Optional[str] = None,
        expense_date: Optional[str] = None,
    ) -> Expense:
        """Update fields of an existing expense."""
        existing = self.get_expense(expense_id)

        updates: List[str] = []
        params: List[Any] = []

        if amount is not None:
            updates.append("amount = ?")
            params.append(amount)
            existing.amount = amount

        if category is not None:
            updates.append("category = ?")
            params.append(category)
            existing.category = category

        if description is not None:
            updates.append("description = ?")
            params.append(description)
            existing.description = description

        if expense_date is not None:
            updates.append("date = ?")
            params.append(expense_date)
            existing.date = expense_date

        if not updates:
            return existing

        params.append(expense_id)
        sql = f"UPDATE expenses SET {', '.join(updates)} WHERE id = ?;"

        try:
            with self._connection() as conn:
                conn.execute(sql, params)
                return existing
        except sqlite3.Error as err:
            raise StorageError(f"Failed to update expense #{expense_id}: {err}") from err

    def delete_expense(self, expense_id: int) -> Expense:
        """Delete an expense by ID and return the deleted record."""
        existing = self.get_expense(expense_id)
        sql = "DELETE FROM expenses WHERE id = ?;"
        try:
            with self._connection() as conn:
                conn.execute(sql, (expense_id,))
                return existing
        except sqlite3.Error as err:
            raise StorageError(f"Failed to delete expense #{expense_id}: {err}") from err

    # Budget Management
    def set_budget(self, budget: Budget) -> Budget:
        """Upsert a monthly category budget."""
        sql = """
            INSERT INTO budgets (category, month, monthly_limit)
            VALUES (?, ?, ?)
            ON CONFLICT(category, month) DO UPDATE SET monthly_limit = excluded.monthly_limit;
        """
        try:
            with self._connection() as conn:
                conn.execute(sql, (budget.category, budget.month, budget.monthly_limit))
                return budget
        except sqlite3.Error as err:
            raise StorageError(f"Failed to set budget: {err}") from err

    def get_budget(self, category: str, month: str) -> Optional[Budget]:
        """Fetch budget for a category and month."""
        sql = "SELECT category, month, monthly_limit FROM budgets WHERE category = ? AND month = ?;"
        try:
            with self._connection() as conn:
                row = conn.execute(sql, (category, month)).fetchone()
                if row is None:
                    return None
                return Budget(
                    category=row["category"],
                    monthly_limit=row["monthly_limit"],
                    month=row["month"],
                )
        except sqlite3.Error as err:
            raise StorageError(f"Failed to query budget: {err}") from err

    def list_budgets(self, month: str) -> List[Budget]:
        """List all budgets configured for a given month."""
        sql = "SELECT category, month, monthly_limit FROM budgets WHERE month = ? ORDER BY category ASC;"
        try:
            with self._connection() as conn:
                rows = conn.execute(sql, (month,)).fetchall()
                return [
                    Budget(
                        category=r["category"],
                        monthly_limit=r["monthly_limit"],
                        month=r["month"],
                    )
                    for r in rows
                ]
        except sqlite3.Error as err:
            raise StorageError(f"Failed to list budgets: {err}") from err

    def delete_budget(self, category: str, month: str) -> bool:
        """Delete a budget entry. Returns True if deleted, False if did not exist."""
        sql = "DELETE FROM budgets WHERE category = ? AND month = ?;"
        try:
            with self._connection() as conn:
                cursor = conn.execute(sql, (category, month))
                return cursor.rowcount > 0
        except sqlite3.Error as err:
            raise StorageError(f"Failed to delete budget: {err}") from err

    # Analytics queries
    def get_category_totals(self, month: Optional[str] = None) -> List[Tuple[str, float, int]]:
        """Return list of (category, total_spent, transaction_count)."""
        where = "WHERE strftime('%Y-%m', date) = ?" if month else ""
        params = [month] if month else []
        sql = f"""
            SELECT category, SUM(amount) AS total, COUNT(id) AS count
            FROM expenses
            {where}
            GROUP BY category
            ORDER BY total DESC;
        """
        try:
            with self._connection() as conn:
                rows = conn.execute(sql, params).fetchall()
                return [(r["category"], round(float(r["total"]), 2), int(r["count"])) for r in rows]
        except sqlite3.Error as err:
            raise StorageError(f"Failed to calculate category totals: {err}") from err

    def get_monthly_totals(self, year: Optional[str] = None) -> List[Tuple[str, float, int]]:
        """Return list of (month, total_spent, count) for a year or all time."""
        where = "WHERE strftime('%Y', date) = ?" if year else ""
        params = [year] if year else []
        sql = f"""
            SELECT strftime('%Y-%m', date) AS month, SUM(amount) AS total, COUNT(id) AS count
            FROM expenses
            {where}
            GROUP BY month
            ORDER BY month ASC;
        """
        try:
            with self._connection() as conn:
                rows = conn.execute(sql, params).fetchall()
                return [(r["month"], round(float(r["total"]), 2), int(r["count"])) for r in rows]
        except sqlite3.Error as err:
            raise StorageError(f"Failed to calculate monthly totals: {err}") from err
