"""Custom exception hierarchy for SpendWise CLI application.

This module provides specialized exception classes to distinguish
between validation failures, storage errors, and business rule violations.
"""


class SpendWiseError(Exception):
    """Base exception for all SpendWise application errors."""

    def __init__(self, message: str, hint: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self) -> str:
        if self.hint:
            return f"{self.message} (Hint: {self.hint})"
        return self.message


class ValidationError(SpendWiseError):
    """Raised when user input fails validation constraints."""

    pass


class ExpenseNotFoundError(SpendWiseError):
    """Raised when an expense with the requested ID is not found."""

    def __init__(self, expense_id: int) -> None:
        super().__init__(
            message=f"Expense with ID {expense_id} not found.",
            hint="Run 'spendwise list' to see all existing expense IDs.",
        )
        self.expense_id = expense_id


class BudgetNotFoundError(SpendWiseError):
    """Raised when a budget for a requested category/month is not found."""

    def __init__(self, category: str, month: str) -> None:
        super().__init__(
            message=f"No budget set for category '{category}' in month '{month}'.",
            hint=f"Use 'spendwise budget set {category} <amount> -m {month}' to create one.",
        )
        self.category = category
        self.month = month


class StorageError(SpendWiseError):
    """Raised when reading or writing to the database/files fails."""

    pass


class ExportImportError(SpendWiseError):
    """Raised when exporting or importing expense data fails."""

    pass
