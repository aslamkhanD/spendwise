"""Command-Line Interface entry point for SpendWise.

Handles CLI argument parsing, subcommands dispatch, and top-level
exception handling to provide user-friendly messages and proper exit codes.
"""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from spendwise import __version__
from spendwise.exceptions import SpendWiseError
from spendwise.formatters import (
    BOLD,
    CYAN,
    GREEN,
    RED,
    YELLOW,
    colorize,
    format_currency,
    render_budget_status,
    render_category_chart,
    render_expenses_table,
    render_table,
)
from spendwise.tracker import ExpenseTracker


def build_parser() -> argparse.ArgumentParser:
    """Construct and configure the argparse argument parser."""
    parser = argparse.ArgumentParser(
        prog="spendwise",
        description=colorize("SpendWise - Modern Personal Expense & Budget Tracker CLI", BOLD),
        epilog="Use 'spendwise <command> --help' for details on a specific command.",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"SpendWise CLI v{__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Command: add
    add_parser = subparsers.add_parser("add", help="Add a new expense")
    add_parser.add_argument("-a", "--amount", required=True, help="Expense amount (e.g. 24.50)")
    add_parser.add_argument("-c", "--category", required=True, help="Category name (e.g. Food, Transport)")
    add_parser.add_argument("-d", "--description", default="", help="Optional description or note")
    add_parser.add_argument("--date", default=None, help="Date (YYYY-MM-DD, 'today', or 'yesterday')")

    # Command: list
    list_parser = subparsers.add_parser("list", help="List and filter expenses")
    list_parser.add_argument("-c", "--category", default=None, help="Filter by category")
    list_parser.add_argument("-m", "--month", default=None, help="Filter by month (YYYY-MM)")
    list_parser.add_argument("--from", dest="from_date", default=None, help="Start date (YYYY-MM-DD)")
    list_parser.add_argument("--to", dest="to_date", default=None, help="End date (YYYY-MM-DD)")
    list_parser.add_argument(
        "--sort",
        choices=["date", "amount", "category", "id"],
        default="date",
        help="Column to sort by (default: date)",
    )
    list_parser.add_argument(
        "--desc",
        action="store_true",
        help="Sort in descending order (default: ascending)",
    )

    # Command: show
    show_parser = subparsers.add_parser("show", help="Display details of an expense by ID")
    show_parser.add_argument("id", help="Numeric ID of the expense")

    # Command: update
    update_parser = subparsers.add_parser("update", help="Update an existing expense")
    update_parser.add_argument("id", help="Numeric ID of the expense to update")
    update_parser.add_argument("-a", "--amount", default=None, help="New expense amount")
    update_parser.add_argument("-c", "--category", default=None, help="New category")
    update_parser.add_argument("-d", "--description", default=None, help="New description")
    update_parser.add_argument("--date", default=None, help="New date (YYYY-MM-DD)")

    # Command: delete
    delete_parser = subparsers.add_parser("delete", help="Delete an expense by ID")
    delete_parser.add_argument("id", help="Numeric ID of the expense to delete")
    delete_parser.add_argument(
        "-y", "--yes",
        action="store_true",
        help="Skip deletion confirmation prompt",
    )

    # Command: summary
    summary_parser = subparsers.add_parser("summary", help="Show spending summary and analytics")
    summary_parser.add_argument("-m", "--month", default=None, help="Specific month (YYYY-MM)")
    summary_parser.add_argument("-y", "--year", default=None, help="Specific year (YYYY)")
    summary_parser.add_argument(
        "--chart",
        action="store_true",
        default=True,
        help="Display visual category chart (default: enabled)",
    )

    # Command: budget
    budget_parser = subparsers.add_parser("budget", help="Manage category monthly budgets")
    budget_sub = budget_parser.add_subparsers(dest="budget_action", help="Budget operations")

    b_set = budget_sub.add_parser("set", help="Set or update a monthly category budget")
    b_set.add_argument("category", help="Category name")
    b_set.add_argument("limit", help="Monthly budget limit amount")
    b_set.add_argument("-m", "--month", default=None, help="Target month (YYYY-MM, default: current)")

    b_status = budget_sub.add_parser("status", help="Check spending against monthly budgets")
    b_status.add_argument("-m", "--month", default=None, help="Month to check (YYYY-MM, default: current)")

    b_del = budget_sub.add_parser("delete", help="Remove a monthly budget")
    b_del.add_argument("category", help="Category name")
    b_del.add_argument("-m", "--month", default=None, help="Target month (YYYY-MM, default: current)")

    # Command: export
    export_parser = subparsers.add_parser("export", help="Export expense data to file")
    export_parser.add_argument("file", help="Destination file path (e.g. expenses.csv or expenses.json)")
    export_parser.add_argument(
        "-f", "--format",
        choices=["csv", "json"],
        default="csv",
        help="Export format (default: csv)",
    )

    # Command: import
    import_parser = subparsers.add_parser("import", help="Import expenses from CSV or JSON")
    import_parser.add_argument("file", help="Source file path to import")

    return parser


def handle_add(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    expense, warning = tracker.add(
        amount=args.amount,
        category=args.category,
        description=args.description,
        expense_date=args.date,
    )
    print(colorize(f"Successfully added expense #{expense.id}!", BOLD, GREEN))
    print(f"  Amount:      {format_currency(expense.amount)}")
    print(f"  Category:    {expense.category}")
    print(f"  Date:        {expense.date}")
    if expense.description:
        print(f"  Description: {expense.description}")

    if warning:
        print("\n" + colorize(warning, YELLOW, BOLD))
    return 0


def handle_list(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    order = "DESC" if args.desc else "ASC"
    expenses = tracker.list(
        category=args.category,
        month=args.month,
        start_date=args.from_date,
        end_date=args.to_date,
        sort_by=args.sort,
        order=order,
    )
    print(render_expenses_table(expenses))
    return 0


def handle_show(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    exp = tracker.get(args.id)
    headers = ["Field", "Value"]
    rows = [
        ["ID", str(exp.id)],
        ["Date", exp.date],
        ["Category", exp.category],
        ["Amount", format_currency(exp.amount)],
        ["Description", exp.description or "-"],
        ["Recorded At", exp.created_at or "-"],
    ]
    print(render_table(headers, rows))
    return 0


def handle_update(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    if not any([args.amount, args.category, args.description is not None, args.date]):
        print(colorize("No fields specified for update. Use -a, -c, -d, or --date.", YELLOW))
        return 1

    updated = tracker.update(
        expense_id=args.id,
        amount=args.amount,
        category=args.category,
        description=args.description,
        expense_date=args.date,
    )
    print(colorize(f"Successfully updated expense #{updated.id}!", BOLD, GREEN))
    return 0


def handle_delete(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    if not args.yes:
        confirm = input(colorize(f"Are you sure you want to delete expense #{args.id}? (y/N): ", YELLOW))
        if confirm.strip().lower() not in ("y", "yes"):
            print("Operation canceled.")
            return 0

    deleted = tracker.delete(args.id)
    print(colorize(f"Successfully deleted expense #{deleted.id} ({format_currency(deleted.amount)} - {deleted.category}).", GREEN))
    return 0


def handle_summary(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    summary = tracker.get_summary(month=args.month, year=args.year)
    period = summary["period"]
    total = summary["total_spent"]
    count = summary["transaction_count"]

    print(colorize(f"\n=== Financial Summary: {period} ===", BOLD, CYAN))
    print(f"Total Spending:      {colorize(format_currency(total), BOLD)}")
    print(f"Total Transactions:  {count}")
    print()

    if summary["category_totals"]:
        print(render_category_chart(summary["category_totals"]))
        print()

    if summary["monthly_trends"] and not args.month:
        headers = ["Month", "Spent", "Count"]
        rows = [[m, format_currency(tot), str(cnt)] for m, tot, cnt in summary["monthly_trends"]]
        print(colorize("Monthly Trends:", BOLD))
        print(render_table(headers, rows))

    return 0


def handle_budget(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    action = args.budget_action
    if not action or action == "status":
        month = getattr(args, "month", None)
        status = tracker.get_budget_status(month=month)
        print(colorize(f"\n=== Budget Status ({month or 'Current Month'}) ===", BOLD, CYAN))
        print(render_budget_status(status))
        return 0

    if action == "set":
        b = tracker.set_budget(args.category, args.limit, args.month)
        print(colorize(f"Budget for '{b.category}' set to {format_currency(b.monthly_limit)} for {b.month}!", GREEN))
        return 0

    if action == "delete":
        deleted = tracker.delete_budget(args.category, args.month)
        if deleted:
            print(colorize(f"Budget for '{args.category}' removed successfully.", GREEN))
        else:
            print(colorize(f"No existing budget found for '{args.category}'.", YELLOW))
        return 0

    return 0


def handle_export(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    count = tracker.export_data(file_path=args.file, export_format=args.format)
    print(colorize(f"Exported {count} expense(s) to '{args.file}' ({args.format.upper()}).", GREEN))
    return 0


def handle_import(tracker: ExpenseTracker, args: argparse.Namespace) -> int:
    count = tracker.import_data(file_path=args.file)
    print(colorize(f"Successfully imported {count} expense(s) from '{args.file}'!", GREEN))
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """Main CLI execution routine."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    tracker = ExpenseTracker()

    try:
        if args.command == "add":
            return handle_add(tracker, args)
        elif args.command == "list":
            return handle_list(tracker, args)
        elif args.command == "show":
            return handle_show(tracker, args)
        elif args.command == "update":
            return handle_update(tracker, args)
        elif args.command == "delete":
            return handle_delete(tracker, args)
        elif args.command == "summary":
            return handle_summary(tracker, args)
        elif args.command == "budget":
            return handle_budget(tracker, args)
        elif args.command == "export":
            return handle_export(tracker, args)
        elif args.command == "import":
            return handle_import(tracker, args)
        else:
            parser.print_help()
            return 0
    except SpendWiseError as err:
        print(colorize(f"Error: {err}", BOLD, RED), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print(colorize("\nInterrupted by user. Exiting.", YELLOW), file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
