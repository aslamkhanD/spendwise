"""Data models for SpendWise CLI application.

Defines dataclasses for Expense, Budget, and summary statistics.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Dict


@dataclass(slots=True)
class Expense:
    """Represents an individual financial expense."""

    id: int | None
    amount: float
    category: str
    description: str
    date: str  # YYYY-MM-DD
    created_at: str | None = None

    def __post_init__(self) -> None:
        if self.created_at is None:
            self.created_at = datetime.now().isoformat(timespec="seconds")

    def to_dict(self) -> Dict[str, Any]:
        """Convert expense to dictionary representation."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Expense:
        """Create an Expense instance from a dictionary."""
        return cls(
            id=data.get("id"),
            amount=float(data["amount"]),
            category=str(data["category"]),
            description=str(data.get("description", "")),
            date=str(data["date"]),
            created_at=data.get("created_at"),
        )


@dataclass(slots=True)
class Budget:
    """Represents a monthly spending budget for a specific category."""

    category: str
    monthly_limit: float
    month: str  # YYYY-MM

    def to_dict(self) -> Dict[str, Any]:
        """Convert budget to dictionary representation."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Budget:
        """Create a Budget instance from a dictionary."""
        return cls(
            category=str(data["category"]),
            monthly_limit=float(data["monthly_limit"]),
            month=str(data["month"]),
        )


@dataclass(slots=True)
class BudgetComparison:
    """Comparison between monthly budget and actual spending."""

    category: str
    monthly_limit: float
    spent: float
    remaining: float
    percentage_used: float
    is_exceeded: bool
