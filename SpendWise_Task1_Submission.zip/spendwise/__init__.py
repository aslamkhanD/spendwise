"""SpendWise - Personal Expense & Budget Tracker CLI.

A modular, robust command-line application built with Python.
"""

__version__ = "1.0.0"
__author__ = "Antigravity Pair Programmer"
