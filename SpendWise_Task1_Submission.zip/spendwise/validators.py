"""Validation functions for user inputs in SpendWise CLI.

This module enforces domain constraints and data formatting rules.
"""

from __future__ import annotations

from datetime import date, datetime
import re
from typing import Sequence

from spendwise.exceptions import ValidationError

# Allowed standard categories (users can also define custom ones)
DEFAULT_CATEGORIES: Sequence[str] = (
    "Food",
    "Transport",
    "Housing",
    "Utilities",
    "Entertainment",
    "Health",
    "Shopping",
    "Education",
    "Travel",
    "Miscellaneous",
)

DATE_FORMAT = "%Y-%m-%d"
MONTH_FORMAT = "%Y-%m"


def validate_amount(value: float | int | str) -> float:
    """Validate and normalize an expense amount.

    Args:
        value: Number or string representing money amount.

    Returns:
        float: Rounded to 2 decimal places.

    Raises:
        ValidationError: If value is non-numeric, negative, zero, or exceeds upper bound.
    """
    try:
        amount = float(value)
    except (TypeError, ValueError) as err:
        raise ValidationError(
            f"Invalid amount '{value}'. Amount must be a valid number.",
            hint="Example: 15.50 or 120",
        ) from err

    if amount <= 0:
        raise ValidationError(
            f"Amount must be strictly greater than 0, got {amount:.2f}.",
            hint="Expenses represent money spent, so they must be positive numbers.",
        )

    if amount > 1_000_000_000:
        raise ValidationError(
            f"Amount {amount:.2f} exceeds realistic transaction limit (1,000,000,000).",
            hint="Check if you entered extra zeroes by mistake.",
        )

    return round(amount, 2)


def validate_date(value: str | date | None) -> str:
    """Validate and normalize an ISO date string (YYYY-MM-DD).

    Supports keywords like 'today' or 'yesterday'.

    Args:
        value: Date string or date instance. If None, defaults to today.

    Returns:
        str: ISO formatted date string (YYYY-MM-DD).

    Raises:
        ValidationError: If the format is invalid or represents an impossible calendar date.
    """
    if value is None:
        return date.today().strftime(DATE_FORMAT)

    if isinstance(value, date):
        return value.strftime(DATE_FORMAT)

    cleaned = value.strip().lower()

    if cleaned == "today":
        return date.today().strftime(DATE_FORMAT)

    if cleaned == "yesterday":
        from datetime import timedelta
        return (date.today() - timedelta(days=1)).strftime(DATE_FORMAT)

    try:
        parsed = datetime.strptime(cleaned, DATE_FORMAT).date()
    except ValueError as err:
        raise ValidationError(
            f"Invalid date format: '{value}'. Expected YYYY-MM-DD.",
            hint="Example: 2026-11-15 or simply 'today'.",
        ) from err

    # Sanity check: prevent dates far into the future (e.g. > 1 year)
    today = date.today()
    if parsed.year > today.year + 1:
        raise ValidationError(
            f"Date '{value}' is too far in the future.",
            hint=f"Please enter a date within the current or upcoming year ({today.year}).",
        )

    if parsed.year < 1970:
        raise ValidationError(
            f"Date '{value}' is too far in the past.",
            hint="Please enter a date after 1970.",
        )

    return parsed.strftime(DATE_FORMAT)


def validate_month(value: str | None) -> str:
    """Validate and normalize a month string (YYYY-MM).

    Args:
        value: String like '2026-11', or None for current month.

    Returns:
        str: Formatted YYYY-MM.

    Raises:
        ValidationError: If format or month number is invalid.
    """
    if value is None:
        return date.today().strftime(MONTH_FORMAT)

    cleaned = value.strip().lower()
    if cleaned == "current" or cleaned == "this":
        return date.today().strftime(MONTH_FORMAT)

    try:
        parsed = datetime.strptime(cleaned, MONTH_FORMAT)
    except ValueError as err:
        raise ValidationError(
            f"Invalid month format: '{value}'. Expected YYYY-MM.",
            hint="Example: 2026-11",
        ) from err

    return parsed.strftime(MONTH_FORMAT)


def validate_category(value: str) -> str:
    """Validate and normalize a category name.

    Args:
        value: Name of the category.

    Returns:
        str: Cleaned, title-cased category string.

    Raises:
        ValidationError: If empty or contains invalid characters.
    """
    if not value or not isinstance(value, str):
        raise ValidationError(
            "Category cannot be empty.",
            hint=f"Suggested categories: {', '.join(DEFAULT_CATEGORIES[:5])}...",
        )

    cleaned = value.strip()
    if len(cleaned) < 2:
        raise ValidationError(
            f"Category name '{cleaned}' is too short (min 2 characters).",
            hint="Provide a meaningful category name like 'Food' or 'Travel'.",
        )

    if len(cleaned) > 50:
        raise ValidationError(
            f"Category name is too long ({len(cleaned)} characters, max 50).",
        )

    if re.search(r"[<>{}\[\];=]", cleaned):
        raise ValidationError(
            f"Category name contains illegal characters: '{cleaned}'.",
            hint="Category names should only contain alphanumeric characters, spaces, and hyphens.",
        )

    return cleaned.title()


def validate_description(value: str | None) -> str:
    """Validate and sanitize an expense description.

    Args:
        value: Raw description string or None.

    Returns:
        str: Sanitized description (or empty string if none provided).

    Raises:
        ValidationError: If length exceeds maximum.
    """
    if value is None:
        return ""

    cleaned = value.strip()
    if len(cleaned) > 255:
        raise ValidationError(
            f"Description is too long ({len(cleaned)} characters, max 255).",
            hint="Keep descriptions brief and concise.",
        )

    return cleaned


def validate_id(value: int | str) -> int:
    """Validate an entity ID.

    Args:
        value: String or integer ID.

    Returns:
        int: Positive integer ID.

    Raises:
        ValidationError: If not a positive integer.
    """
    try:
        num = int(value)
        if num <= 0:
            raise ValueError()
    except (TypeError, ValueError) as err:
        raise ValidationError(
            f"Invalid ID '{value}'. ID must be a positive integer.",
            hint="Check the list of expenses with 'spendwise list' to find the numeric ID.",
        ) from err

    return num
