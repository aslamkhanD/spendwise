"""Core business logic for SpendWise CLI application.

Coordinates between input validation, storage persistence,
budget warnings, and data export/import workflows.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from spendwise.exceptions import ExportImportError, ValidationError
from spendwise.models import Budget, BudgetComparison, Expense
from spendwise.storage import Storage
from spendwise.validators import (
    validate_amount,
    validate_category,
    validate_date,
    validate_description,
    validate_id,
    validate_month,
)


class ExpenseTracker:
    """Service that manages expenses, budgets, summaries, and file operations."""

    def __init__(self, storage: Optional[Storage] = None) -> None:
        self.storage = storage or Storage()

    def add(
        self,
        amount: float | str,
        category: str,
        description: str = "",
        expense_date: Optional[str] = None,
    ) -> Tuple[Expense, Optional[str]]:
        """Add a new expense with validation and budget checking.

        Returns:
            Tuple[Expense, Optional[str]]: The created expense and an optional budget warning.
        """
        valid_amount = validate_amount(amount)
        valid_category = validate_category(category)
        valid_description = validate_description(description)
        valid_date = validate_date(expense_date)

        expense = Expense(
            id=None,
            amount=valid_amount,
            category=valid_category,
            description=valid_description,
            date=valid_date,
        )

        saved = self.storage.add_expense(expense)

        # Check if this new expense triggers a budget warning
        warning = None
        month_str = valid_date[:7]
        budget = self.storage.get_budget(valid_category, month_str)
        if budget:
            month_expenses = self.storage.list_expenses(category=valid_category, month=month_str)
            total_spent = sum(e.amount for e in month_expenses)
            if total_spent > budget.monthly_limit:
                excess = total_spent - budget.monthly_limit
                warning = (
                    f"Warning: Spending for '{valid_category}' in {month_str} is now ${total_spent:,.2f}, "
                    f"exceeding your monthly budget of ${budget.monthly_limit:,.2f} by ${excess:,.2f}!"
                )
            elif total_spent >= budget.monthly_limit * 0.9:
                pct = (total_spent / budget.monthly_limit) * 100.0
                warning = (
                    f"Notice: You have used {pct:.1f}% of your '{valid_category}' budget "
                    f"(${total_spent:,.2f} / ${budget.monthly_limit:,.2f}) for {month_str}."
                )

        return saved, warning

    def get(self, expense_id: int | str) -> Expense:
        """Fetch a single expense by ID."""
        valid_id = validate_id(expense_id)
        return self.storage.get_expense(valid_id)

    def list(
        self,
        category: Optional[str] = None,
        month: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        sort_by: str = "date",
        order: str = "ASC",
    ) -> List[Expense]:
        """List expenses matching filters."""
        val_category = validate_category(category) if category else None
        val_month = validate_month(month) if month else None
        val_start = validate_date(start_date) if start_date else None
        val_end = validate_date(end_date) if end_date else None

        if val_start and val_end and val_start > val_end:
            raise ValidationError(
                f"Start date ({val_start}) cannot be later than end date ({val_end}).",
                hint="Verify your date range flags (--from and --to).",
            )

        return self.storage.list_expenses(
            category=val_category,
            month=val_month,
            start_date=val_start,
            end_date=val_end,
            sort_by=sort_by,
            order=order,
        )

    def update(
        self,
        expense_id: int | str,
        amount: Optional[float | str] = None,
        category: Optional[str] = None,
        description: Optional[str] = None,
        expense_date: Optional[str] = None,
    ) -> Expense:
        """Update an existing expense."""
        valid_id = validate_id(expense_id)
        val_amount = validate_amount(amount) if amount is not None else None
        val_category = validate_category(category) if category is not None else None
        val_desc = validate_description(description) if description is not None else None
        val_date = validate_date(expense_date) if expense_date is not None else None

        return self.storage.update_expense(
            expense_id=valid_id,
            amount=val_amount,
            category=val_category,
            description=val_desc,
            expense_date=val_date,
        )

    def delete(self, expense_id: int | str) -> Expense:
        """Delete an expense by ID."""
        valid_id = validate_id(expense_id)
        return self.storage.delete_expense(valid_id)

    # Budget operations
    def set_budget(self, category: str, limit: float | str, month: Optional[str] = None) -> Budget:
        """Set or update a monthly budget for a category."""
        val_cat = validate_category(category)
        val_limit = validate_amount(limit)
        val_month = validate_month(month)

        budget = Budget(category=val_cat, monthly_limit=val_limit, month=val_month)
        return self.storage.set_budget(budget)

    def get_budget_status(self, month: Optional[str] = None) -> List[BudgetComparison]:
        """Compute budget health comparison for all configured categories in the given month."""
        val_month = validate_month(month)
        budgets = self.storage.list_budgets(val_month)
        month_expenses = self.storage.list_expenses(month=val_month)

        # Aggregate spending by category
        spent_by_category: Dict[str, float] = {}
        for exp in month_expenses:
            spent_by_category[exp.category] = spent_by_category.get(exp.category, 0.0) + exp.amount

        comparisons: List[BudgetComparison] = []
        for b in budgets:
            spent = spent_by_category.get(b.category, 0.0)
            remaining = b.monthly_limit - spent
            pct = (spent / b.monthly_limit) * 100.0 if b.monthly_limit > 0 else 0.0
            comparisons.append(
                BudgetComparison(
                    category=b.category,
                    monthly_limit=b.monthly_limit,
                    spent=spent,
                    remaining=remaining,
                    percentage_used=pct,
                    is_exceeded=spent > b.monthly_limit,
                )
            )

        return comparisons

    def delete_budget(self, category: str, month: Optional[str] = None) -> bool:
        """Delete a configured budget."""
        val_cat = validate_category(category)
        val_month = validate_month(month)
        return self.storage.delete_budget(val_cat, val_month)

    # Summary and analytics
    def get_summary(
        self, month: Optional[str] = None, year: Optional[str] = None
    ) -> Dict[str, Any]:
        """Generate high-level summary statistics."""
        val_month = validate_month(month) if month else None
        category_totals = self.storage.get_category_totals(month=val_month)
        monthly_trends = self.storage.get_monthly_totals(year=year)

        total_amount = sum(t[1] for t in category_totals)
        total_tx = sum(t[2] for t in category_totals)

        return {
            "period": val_month or (f"Year {year}" if year else "All Time"),
            "total_spent": total_amount,
            "transaction_count": total_tx,
            "category_totals": category_totals,
            "monthly_trends": monthly_trends,
        }

    # Export & Import
    def export_data(self, file_path: Path | str, export_format: str = "csv") -> int:
        """Export all expenses to CSV or JSON format.

        Returns:
            int: Number of exported records.
        """
        path = Path(file_path)
        expenses = self.storage.list_expenses(sort_by="date", order="ASC")

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            fmt = export_format.lower()

            if fmt == "csv":
                with open(path, mode="w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(
                        f,
                        fieldnames=["id", "date", "category", "amount", "description", "created_at"],
                    )
                    writer.writeheader()
                    for exp in expenses:
                        writer.writerow(exp.to_dict())
            elif fmt == "json":
                with open(path, mode="w", encoding="utf-8") as f:
                    data = [exp.to_dict() for exp in expenses]
                    json.dump(data, f, indent=2)
            else:
                raise ExportImportError(
                    f"Unsupported export format '{export_format}'. Supported: 'csv', 'json'."
                )

            return len(expenses)
        except OSError as err:
            raise ExportImportError(f"Failed to write export file '{path}': {err}") from err

    def import_data(self, file_path: Path | str) -> int:
        """Import expenses from CSV or JSON file.

        Returns:
            int: Number of successfully imported expenses.
        """
        path = Path(file_path)
        if not path.is_file():
            raise ExportImportError(f"Import file not found: '{path}'")

        imported_count = 0
        try:
            if path.suffix.lower() == ".json":
                with open(path, mode="r", encoding="utf-8") as f:
                    records = json.load(f)
                    if not isinstance(records, list):
                        raise ExportImportError("JSON file must contain an array of expense objects.")
            elif path.suffix.lower() == ".csv":
                with open(path, mode="r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    records = list(reader)
            else:
                raise ExportImportError(
                    f"Unsupported file type '{path.suffix}'. Please provide a .csv or .json file."
                )

            for idx, item in enumerate(records, start=1):
                try:
                    amount = validate_amount(item.get("amount"))
                    category = validate_category(str(item.get("category", "")))
                    desc = validate_description(str(item.get("description", "")))
                    date_val = validate_date(item.get("date"))

                    exp = Expense(
                        id=None,
                        amount=amount,
                        category=category,
                        description=desc,
                        date=date_val,
                    )
                    self.storage.add_expense(exp)
                    imported_count += 1
                except ValidationError as v_err:
                    raise ExportImportError(
                        f"Error in record #{idx}: {v_err.message}"
                    ) from v_err

            return imported_count
        except (json.JSONDecodeError, csv.Error) as err:
            raise ExportImportError(f"Malformed file contents in '{path}': {err}") from err
        except OSError as err:
            raise ExportImportError(f"Could not read import file '{path}': {err}") from err
