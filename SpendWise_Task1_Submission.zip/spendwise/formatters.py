"""Formatting and terminal rendering utilities for SpendWise CLI.

Provides zero-dependency table rendering, ANSI color formatting,
and visual ASCII bar charts for expense distribution and budget health.
"""

from __future__ import annotations

import os
import sys
from typing import List, Sequence, Tuple

from spendwise.models import BudgetComparison, Expense

# ANSI color codes
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"


def _supports_color() -> bool:
    """Check if standard output supports ANSI color codes."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty() or os.name == "nt"


def colorize(text: str, *codes: str) -> str:
    """Apply ANSI style codes if terminal supports them."""
    if not _supports_color() or not codes:
        return text
    return f"{''.join(codes)}{text}{RESET}"


def format_currency(amount: float) -> str:
    """Format floating point amount into standard currency string ($1,234.56)."""
    return f"${amount:,.2f}"


def render_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    """Render a clean ASCII table with headers, borders, and aligned cells."""
    if not headers and not rows:
        return ""

    num_cols = len(headers)
    widths = [len(str(h)) for h in headers]

    for row in rows:
        for idx, cell in enumerate(row):
            if idx < num_cols:
                widths[idx] = max(widths[idx], len(str(cell)))

    # Construct border components
    top = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    header_line = "| " + " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers)) + " |"
    divider = "+" + "+".join("=" * (w + 2) for w in widths) + "+"
    bottom = "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    row_lines = []
    for row in rows:
        cells = [str(row[i]).ljust(widths[i]) if i < len(row) else "".ljust(widths[i]) for i in range(num_cols)]
        row_lines.append("| " + " | ".join(cells) + " |")

    lines = [top, colorize(header_line, BOLD), divider]
    lines.extend(row_lines)
    lines.append(bottom)
    return "\n".join(lines)


def render_expenses_table(expenses: Sequence[Expense]) -> str:
    """Format a list of expenses into a stylized table."""
    if not expenses:
        return colorize("No expenses found.", DIM)

    headers = ["ID", "Date", "Category", "Amount", "Description"]
    rows = []
    total = 0.0

    for exp in expenses:
        total += exp.amount
        rows.append([
            str(exp.id or "-"),
            exp.date,
            exp.category,
            format_currency(exp.amount),
            exp.description or colorize("-", DIM),
        ])

    table = render_table(headers, rows)
    footer = colorize(
        f"\nTotal: {len(expenses)} expense(s) | Sum: {format_currency(total)}",
        BOLD,
        CYAN,
    )
    return f"{table}\n{footer}"


def render_bar(percentage: float, width: int = 24) -> str:
    """Render a visual ASCII progress/distribution bar."""
    pct = max(0.0, min(percentage, 100.0))
    filled_len = int(round((pct / 100.0) * width))
    bar = "█" * filled_len + "░" * (width - filled_len)

    if pct >= 100:
        return colorize(bar, RED)
    elif pct >= 80:
        return colorize(bar, YELLOW)
    return colorize(bar, GREEN)


def render_category_chart(totals: List[Tuple[str, float, int]]) -> str:
    """Render category breakdown with visual proportion bars."""
    if not totals:
        return colorize("No expense data available for this period.", DIM)

    grand_total = sum(t[1] for t in totals)
    if grand_total <= 0:
        return "Total spending: $0.00"

    max_cat_len = max(len(cat) for cat, _, _ in totals)
    lines = [
        colorize(f"Category Breakdown (Total: {format_currency(grand_total)})", BOLD),
        "-" * 65,
    ]

    for category, amount, count in totals:
        pct = (amount / grand_total) * 100.0
        bar = render_bar(pct, width=20)
        pct_str = f"{pct:5.1f}%"
        amt_str = format_currency(amount).rjust(11)
        cnt_str = f"({count} tx)".rjust(8)
        cat_str = category.ljust(max_cat_len)
        lines.append(f"{cat_str}  {bar} {pct_str}  {amt_str} {cnt_str}")

    return "\n".join(lines)


def render_budget_status(comparisons: Sequence[BudgetComparison]) -> str:
    """Render monthly budget health table with warnings for exceeded budgets."""
    if not comparisons:
        return colorize("No budgets set for this month.", DIM)

    headers = ["Category", "Limit", "Spent", "Remaining", "Used %", "Status"]
    rows = []

    for item in comparisons:
        status_text = (
            colorize("OVER BUDGET!", BOLD, RED)
            if item.is_exceeded
            else colorize("On Track", GREEN)
        )
        pct_str = f"{item.percentage_used:.1f}%"

        rows.append([
            item.category,
            format_currency(item.monthly_limit),
            format_currency(item.spent),
            format_currency(item.remaining),
            pct_str,
            status_text,
        ])

    return render_table(headers, rows)
