# SpendWise - Command-Line Expense & Budget Tracker

SpendWise is an extensible command-line interface (CLI) application written in Python for tracking daily expenses, monitoring category budgets, and generating spending summaries.

## Highlights

- **Modular Architecture**: Separate layers for data validation, storage, business logic, and CLI interface.
- **Robust Validation**: Enforces positive amounts, calendar date validation (supporting `today` and `yesterday`), and category restrictions.
- **Custom Exceptions**: Specialized exception hierarchy with actionable suggestions.
- **SQLite Persistence**: Built-in transactional storage with automatic schema setup.
- **Terminal Visualizations**: Clean ASCII tables, status indicators, and horizontal distribution bars without external dependencies.
- **Budget Alerts**: Automatic warnings when spending reaches 90% or exceeds monthly category budgets.
- **Import / Export**: Supports exporting and importing records via CSV or JSON.

---

## Directory Structure

```text
spendwise/
├── main.py                     # Root executable script
├── pyproject.toml              # Build & dependency metadata
├── setup.py                    # Package setup script
├── .gitignore                  # Git ignore rules
├── README.md                   # Project documentation
├── spendwise/                  # Application package
│   ├── __init__.py             # Package initializer
│   ├── exceptions.py          # Custom domain exceptions
│   ├── validators.py          # Input validation functions
│   ├── models.py              # Expense & Budget dataclasses
│   ├── storage.py             # SQLite persistence layer
│   ├── tracker.py             # Core business logic service
│   ├── formatters.py          # ASCII tables & charts
│   └── cli.py                 # Argparse CLI interface
└── tests/                      # Automated test suite
    ├── __init__.py
    ├── test_validators.py
    ├── test_models.py
    ├── test_storage.py
    ├── test_tracker.py
    └── test_cli.py
```

---

## Getting Started

### Prerequisites

- Python 3.9 or higher

### Running the Application

You can execute the application directly:

```bash
python main.py --help
```

Or install it in editable mode:

```bash
pip install -e .
spendwise --help
```

---

## CLI Command Reference

### 1. Adding Expenses

```bash
python main.py add -a 45.50 -c Food -d "Team lunch"
python main.py add -a 120.00 -c Utilities -d "Internet bill" --date 2026-11-01
```

### 2. Listing and Filtering

```bash
# List all expenses
python main.py list

# Filter by category
python main.py list -c Food

# Filter by month (YYYY-MM)
python main.py list -m 2026-11

# Filter by date range and sort descending
python main.py list --from 2026-11-01 --to 2026-11-15 --sort amount --desc
```

### 3. Viewing and Updating

```bash
# Show details of an expense
python main.py show 1

# Update amount or category
python main.py update 1 -a 52.00 -d "Team lunch with beverages"

# Delete an expense
python main.py delete 1 -y
```

### 4. Setting & Monitoring Budgets

```bash
# Set a $300 monthly budget for Food in November 2026
python main.py budget set Food 300 -m 2026-11

# Check budget health and remaining balances
python main.py budget status -m 2026-11
```

### 5. Spending Summaries

```bash
# Monthly summary with category distribution bars
python main.py summary -m 2026-11

# Yearly trends overview
python main.py summary -y 2026
```

### 6. Exporting & Importing

```bash
# Export records to CSV or JSON
python main.py export backup.csv -f csv
python main.py export backup.json -f json

# Import records from file
python main.py import backup.csv
```

---

## Running the Test Suite

Run all unit and integration tests using Python's built-in test runner:

```bash
python -m unittest discover -s tests
```
